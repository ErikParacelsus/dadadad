# How to use
Find:


1. In index.html
```html
var defaultserv = "ogar-unlimited-andrews54757.c9users.io:8081"
```

Change "Ogar-unlimited..." to the ipaddress of your Ogar server.

Find:

2. In Index.html
```html
<div class="form-group">
    <div style="float: left; margin-left: 20px;"><h2>OgarUnlimited.io</h2></div>
```

Change OgarUnlimited.io to a name you like (optional)

3. FInd and change url to server url in the beggining of main_out.js

4. then copy and paste it into the client folder of the ogarul client repo
