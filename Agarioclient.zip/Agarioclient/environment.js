window.EnvConfig = {
    "env_production": true,
    "fb_app_id": 677505792353827,
    "gplus_client_id": "686981379285-oroivr8u2ag1dtm3ntcs6vi05i3cpv0j.apps.googleusercontent.com",
    "master_url": "m.agar.io",
    "xsolla_endpoint": "https://payments.agario.miniclippt.com",
    "fb_endpoint": "https://rewardcallback-live.agario.miniclippt.com/payments/facebook",
    "game_url": "http://agar.io",
    "supersonic_app_key": "416358b5",
    "config_url": "https://configs-web.agario.miniclippt.com/live/v4",
}